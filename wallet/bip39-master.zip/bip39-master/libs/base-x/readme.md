Build (will create a bundle and copy it to /tmp/base-x.js):

    npm install
    npm run build
